package test;

import static org.junit.Assert.*;

import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import appointment.AppointmentService;

public class AppointmentServiceTest {

	@Before
	public void setUp() throws Exception {
		// setup one appointment before running each test
		AppointmentService testAppointment = new AppointmentService();

		String firstAppointmentID = testAppointment.generateAppointmentID();
		Date firstAppointmentDate = new Date();
		String firstDescription = "This is the first appointment!";
				
		testAppointment.addAppointment(firstAppointmentID, firstAppointmentDate, firstDescription);	
	}

	@After
	public void tearDown() throws Exception {
		//clear the appointment list after each test
		AppointmentService.appointmentList.clear();		
	}

	@Test
	public void testAddAppointment() {
		//test adding an appointment
		AppointmentService testAppointment = new AppointmentService();
		
		String newAppointmentID = testAppointment.generateAppointmentID();
		Date newAppointmentDate = new Date();
		Calendar c = Calendar.getInstance();
		c.setTime(newAppointmentDate);
		c.add(Calendar.DATE, 3);
		newAppointmentDate = c.getTime();
		String newDescription = "This is a test for AppointmentService class!";
				
		testAppointment.addAppointment(newAppointmentID, newAppointmentDate, newDescription);
		
		//check in list for appointment that was added and assert values are equal
		for(int i = 0; i < AppointmentService.appointmentList.size(); i++) {
			if(Integer.parseInt(AppointmentService.appointmentList.get(i).getAppointmentID()) == Integer.parseInt(newAppointmentID)) {
				assertEquals(newAppointmentDate, (AppointmentService.appointmentList.get(i).getAppointmentDate()));
				assertEquals(newDescription, AppointmentService.appointmentList.get(i).getDescription());
			}
		}	
	}

	@Test
	public void testDeleteAppointment() {
		//test delete appointment made in @Before
		AppointmentService testAppointment = new AppointmentService();

		String deleteAppointmentID = AppointmentService.appointmentList.get(0).getAppointmentID();
		testAppointment.deleteAppointment(deleteAppointmentID);

		// search for appointment and delete
		for(int i = 0; i < AppointmentService.appointmentList.size(); i++) {
			if(Integer.parseInt(AppointmentService.appointmentList.get(i).getAppointmentID()) == Integer.parseInt(deleteAppointmentID)) {
				assertNotEquals(AppointmentService.appointmentList.get(i).getAppointmentID(), Integer.parseInt(deleteAppointmentID));
			}
		}
	}

}
