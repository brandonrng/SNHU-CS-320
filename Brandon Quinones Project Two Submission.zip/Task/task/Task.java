package task;

public class Task  {
	
	int taskId;
	String taskName;
	String taskDescription;
	
	private final boolean validateTaskId(int taskId) {
		if(String.valueOf(taskId).length() != 10) {
			return false;
		}
		else return true;
	}
	
	private final boolean validateTaskName(String taskName) {
		if(taskName.length() > 20 || taskName.isBlank()) {
			return false;
		}
		else return true;
	}
	
	private final boolean validateTaskDescription(String taskDescription) {
		if(taskDescription.length() > 50 || taskDescription.isBlank()) {
			return false;
		}
		else return true;
	}
	
	public Task(int taskId, String taskName, String taskDescription) {
		if (validateTaskId(taskId) == true)
			this.taskId = taskId;
		setTaskName(taskName);
		setTaskDescription(taskDescription);	
		}

	public int getTaskId() {
		return taskId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		if (validateTaskName(taskName) == true)
			this.taskName = taskName;
	}

	public String getTaskDescription() {
		return taskDescription;
	}

	public void setTaskDescription(String taskDescription) {
		if (validateTaskDescription(taskDescription) == true)
			this.taskDescription = taskDescription;
	}
	
	

}
