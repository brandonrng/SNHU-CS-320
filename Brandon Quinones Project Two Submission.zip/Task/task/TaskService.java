package task;

import java.util.ArrayList;
import java.util.List;

public class TaskService {

	public static List<Task> taskList = new ArrayList <Task>();
	
	public void addTask(int taskId, String taskName, String taskDescription) {
		Task newTask = new Task(taskId, taskName, taskDescription);
		taskList.add(newTask);
	}
	
	public void deleteTask(int taskId) {
		for(int i = 0; i < TaskService.taskList.size(); i++) {
			if(TaskService.taskList.get(i).getTaskId() == (taskId)) {
				taskList.remove(i);
			}
		}
	}
	
	public void editTask(int taskId, String taskName, String taskDescription) {
		Task updatedTask = new Task(taskId, taskName, taskDescription);
		for(int i = 0; i < TaskService.taskList.size(); i++) {
			if(TaskService.taskList.get(i).getTaskId() ==(taskId)) {
				taskList.set(i, updatedTask);
			}
		}
	}
}
