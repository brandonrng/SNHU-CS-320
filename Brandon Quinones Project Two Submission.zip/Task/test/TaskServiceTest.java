package test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import task.TaskService;

public class TaskServiceTest {

	@Before
	public void setUp() throws Exception {
		//sets up 
		int taskId = 1945613251;
		String taskName = "New Task";
		String taskDescription = "This task will be updated with a new name";
		
		TaskService testTask = new TaskService();
        testTask.addTask(taskId, taskName, taskDescription);
	}
	
	@After
	public void tearDown() throws Exception {
		//clears list after each test case
		TaskService.taskList.clear();
	}

	@Test
	public void testAddTask() {
		
		//positive test case
		int taskId = 1566548695;
		String taskName = "New Task";
		String taskDescription = "This task will be added, then deleted";
		
		TaskService testTask = new TaskService();
		
		testTask.addTask(taskId, taskName, taskDescription);
        
        for(int i = 0; i < TaskService.taskList.size(); i++) {
			if(TaskService.taskList.get(i).getTaskId() == taskId) {
				assertEquals(taskName, TaskService.taskList.get(i).getTaskName());
		        assertEquals(taskDescription, TaskService.taskList.get(i).getTaskDescription());
			}
		}
        
        //negative test case - task id not length 10       
        int badTaskId = 56564;
		String badTaskName = "Bad Task";
		String badTaskDescription = "This task should not be added";
				
		testTask.addTask(badTaskId, badTaskName, badTaskDescription);
        
		for(int i = 0; i < TaskService.taskList.size(); i++) {
			assertNotEquals(badTaskId, TaskService.taskList.get(i).getTaskId());
		}
		
        //negative test case - task name null
        badTaskId = 1566234423;
		badTaskName = "";
		badTaskDescription = "This task should not be added";
				
		testTask.addTask(badTaskId, badTaskName, badTaskDescription);
        
		for(int i = 0; i < TaskService.taskList.size(); i++) {
			assertNotEquals(badTaskName, TaskService.taskList.get(i).getTaskName());
		}
		
		//negative test case - task name over limit
        badTaskId = 1566234423;
		badTaskName = "Bad Task - Name over character limit";
		badTaskDescription = "This task should not be added";
				
		testTask.addTask(badTaskId, badTaskName, badTaskDescription);
        
		for(int i = 0; i < TaskService.taskList.size(); i++) {
			assertNotEquals(badTaskName, TaskService.taskList.get(i).getTaskName());
		}

        //negative test case - task description null
        badTaskId = 1512321233;
		badTaskName = "Bad Task";
		badTaskDescription = "";
				
		testTask.addTask(badTaskId, badTaskName, badTaskDescription);
        
		for(int i = 0; i < TaskService.taskList.size(); i++) {
			assertNotEquals(badTaskDescription, TaskService.taskList.get(i).getTaskDescription());
		}

        //negative test case - task description over limit
        badTaskId = 1512321233;
		badTaskName = "Bad Task";
		badTaskDescription = "This task should not be added becuase description is too long"
				+ "jfdklsjfkldasjklfjasdklfjlkasjfklasjdlkfjklasdjfklasjdklfjkldsjklfajlkdsajfk";
				
		testTask.addTask(badTaskId, badTaskName, badTaskDescription);
        
		for(int i = 0; i < TaskService.taskList.size(); i++) {
			assertNotEquals(badTaskDescription, TaskService.taskList.get(i).getTaskDescription());
		}

    }

	@Test
	public void testDeleteTask() {
		//testing deleteTask method
		TaskService testTask = new TaskService();
		int taskId = 1945613251;
		testTask.deleteTask(taskId);
        
		 for(int i = 0; i < TaskService.taskList.size(); i++) {
				assertNotEquals("Failed to delete Task ", taskId, TaskService.taskList.get(i).getTaskId());
			}
	}

	@Test
	public void testEditTask() {
		//testing editTask method - needs all three attributes
		int taskId = 1945613251;
		String taskName = "Updated Task";
		String taskDescription = "This task will be updated with a new name";
		
		TaskService testTask = new TaskService();
		testTask.editTask(taskId, taskName, taskDescription);
        
        for(int i = 0; i < TaskService.taskList.size(); i++) {
        	if(TaskService.taskList.get(i).getTaskId() == (taskId)) {
				assertEquals(taskName, TaskService.taskList.get(i).getTaskName());
		        assertEquals(taskDescription, TaskService.taskList.get(i).getTaskDescription());
			}
		}
	}
}
