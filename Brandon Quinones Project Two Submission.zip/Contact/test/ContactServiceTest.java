package test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import contact.ContactService;

public class ContactServiceTest {

	@Before
	public void setUp() throws Exception {
		ContactService testContact = new ContactService();

		String firstName = "hello";
		String lastName = "world";
		String phoneNumber = "1234567890";
		String address = "132 SNHU Rd.";
				
		testContact.addContact(firstName,lastName,phoneNumber,address);
	}

	@After
	public void tearDown() throws Exception {
		ContactService.contactList.clear();		
	}
	
	@Test
	public void addContact() {
		String firstName = "first";
		String lastName = "last name";
		String phoneNumber = "1234567890";
		String address = "132 SNHU Rd.";
		
		ContactService testContact = new ContactService();
		testContact.addContact(firstName,lastName,phoneNumber,address);
		
		for(int i = 0; i < ContactService.contactList.size(); i++) {
			if(ContactService.contactList.get(i).getContactID().equals(i)) {
				assertEquals(firstName, ContactService.contactList.get(i).getFirstName());
				assertEquals(lastName, ContactService.contactList.get(i).getLastName());
				assertEquals(phoneNumber, ContactService.contactList.get(i).getPhoneNumber());
				assertEquals(address, ContactService.contactList.get(i).getAddress());
			}
		}
	}
}
