package contact;

public class Contact {
	
	String contactID;
	String firstName;
	String lastName;
	String phoneNumber;
	String address;
	
	private final boolean validContactID(String contactID) {
		// Validates the ID Requirements
		if(contactID.length() > 10 || contactID.isBlank()) {
			return false;			
		}		
		return true;
	}

	private final boolean validFirstName(String firstName) {
		// Validates the firstName requirements
		if(firstName.length() > 10 || firstName.isBlank()) {	
			return false;			
		}
		return true;
	}
	private final boolean validLastName(String lastName) {
		// Validates the lastName requirements
		if(lastName.length() > 10 || lastName.isBlank()) {
			return false;			
		}
		return true;
	}

	private final boolean validPhoneNumber(String phoneNumber) {
		// Validates the phoneNumber requirements
		if(phoneNumber.length() != 10 || phoneNumber.isBlank()) {
			return false;			
		}
		return true;
	}
	
	private final boolean validAddress(String address) {
		// Validates the address requirements
		if(address.length() > 30 || address.isBlank()) {
			return false;			
		}
		return true;
	}
	
	
	
	public Contact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
		if (validContactID(contactID))
			this.contactID = contactID;
		else {
			throw new IllegalArgumentException("ContactID cannot be null or over 10 characters");
			}
		setFirstName(firstName);
		setLastName(lastName);
		setPhoneNumber(phoneNumber);
		setAddress(address);
		
	}
	public String getContactID() {
		return contactID;
	}

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		if(!this.validFirstName(firstName)) {
			throw new IllegalArgumentException("FirstName cannot be null or over 10 characters");
		}
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		if(!this.validLastName(lastName)) {
			throw new IllegalArgumentException("LastName cannot be null or over 10 characters");
		}
		this.lastName = lastName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		if(!this.validPhoneNumber(phoneNumber)) {
			throw new IllegalArgumentException("PhoneNumber is not valid");
		}
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		if(!this.validAddress(address)) {
			throw new IllegalArgumentException("Address cannot be null or over 30 characters");
		}
		this.address = address;
	}
	
}
